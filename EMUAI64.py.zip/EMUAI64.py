# EmulAI N64 Emulator
# @FlamesLLC 20XX [C]

import tkinter as tk
from tkinter import filedialog


class EmulAI(tk.Tk):
    def __init__(self):
        super().__init__()

        # Set emulator window properties
        self.title("EmulAI - N64 Emulator")
        self.geometry("600x400")

        # Create main menu bar
        menubar = tk.Menu(self)

        # File menu
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Open ROM", command=self.open_rom)  # Add "Open ROM" option
        # Add other commands here: Save State, Load State etc.
        menubar.add_cascade(label="File", menu=filemenu)

        # Settings menu (Controls, Audio settings etc.)
        settings_menu = tk.Menu(menubar, tearoff=0)
        some_setting_1_var = tk.StringVar(value=' ')
        settings_menu.add_radiobutton(label='Some Setting', variable=some_setting_1_var, value=' ',
                                      command=self.some_function_here)  # Add "Some Setting" option
        menubar.add_cascade(label="Settings", menu=settings_menu)

        # Apply the menu bar to the emulator window
        self.config(menu=menubar)

    # Function to open ROM file
    def open_rom(self):
        file_path = filedialog.askopenfilename(filetypes=[("N64 ROM Files", "*.z64;*.n64")])
        if not file_path:
            return

        print(f"Opening ROM: {file_path}")

    # Placeholder function for "Some Setting" option
    def some_function_here(self):
        pass


# Main function to run the emulator
def main():
    app = EmulAI()
    app.mainloop()


# Start the emulator
if __name__ == "__main__":
    main()
## [PRODULY BY @TEAM FLAMES 20XX [C]]